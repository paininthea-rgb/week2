# info3170-Angular-Week02-Store

[Based on StackBlitz ⚡️](https://stackblitz.com/edit/angular-dbrt7n)
